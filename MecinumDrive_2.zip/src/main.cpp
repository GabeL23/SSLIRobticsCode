/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\spike                                            */
/*    Created:      Sun Mar 08 2020                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
using namespace vex;

int main() {
while(true){
  Intake.setVelocity(120, velocityUnits::pct);
  launcher.setVelocity(60, velocityUnits::pct);
  Roller.setVelocity(50, velocityUnits::pct);
  launcher2.setVelocity(120, velocityUnits::pct);
  double x = Controller1.Axis3.value(); 
  double y = Controller1.Axis4.value();
  double r = Controller1.Axis1.value(); 

  Front_left.spin(vex::directionType::fwd, x + y + r, vex::velocityUnits::pct);
  Front_right.spin(vex::directionType::fwd, x -y - r, vex::velocityUnits::pct);
  Back_left.spin(vex::directionType::fwd, -x -y + r, vex::velocityUnits::pct);
  Back_right.spin(vex::directionType::fwd,  -x  + y - r , vex::velocityUnits::pct);

//*************************Forward and Backwards
//Back_left.spin(vex::directionType::fwd, Controller1.Axis3.value(), vex::velocityUnits::pct);
//Back_right.spin(vex::directionType::fwd, Controller1.Axis3.value(), vex::velocityUnits::pct);
//Front_right.spin(vex::directionType::fwd, Controller1.Axis3.value(), vex::velocityUnits::pct);
//Front_left.spin(vex::directionType::fwd, Controller1.Axis3.value(), vex::velocityUnits::pct);

//**************** Striafe L and R (invesrse in right)*********************
//Back_left.spin(vex::directionType::fwd, Controller1.Axis4.value(), vex::velocityUnits::pct);
//Back_right.spin(vex::directionType::rev, Controller1.Axis4.value(), vex::velocityUnits::pct);
//Front_right.spin(vex::directionType::fwd, Controller1.Axis4.value(), vex::velocityUnits::pct);
//Front_left.spin(vex::directionType::rev, Controller1.Axis4.value(), vex::velocityUnits::pct);

//Turning left***
//if(Controller1.ButtonL1.pressing()) {
//Back_left.spin(vex::directionType::rev, Controller1.Axis3.value(), vex::velocityUnits::pct);
//Back_right.spin(vex::directionType::fwd, Controller1.Axis3.value(), vex::velocityUnits::pct);
//Front_right.spin(vex::directionType::fwd, Controller1.Axis3.value(), vex::velocityUnits::pct);
//Front_left.spin(vex::directionType::rev, Controller1.Axis3.value(), vex::velocityUnits::pct);
//}
//else if(Controller1.ButtonR1.pressing()) {
//Back_left.spin(vex::directionType::fwd, Controller1.Axis3.value(), vex::velocityUnits::pct);
//Back_right.spin(vex::directionType::rev, Controller1.Axis3.value(), vex::velocityUnits::pct);
//Front_right.spin(vex::directionType::rev, Controller1.Axis3.value(), vex::velocityUnits::pct);
//Front_left.spin(vex::directionType::fwd, Controller1.Axis3.value(), vex::velocityUnits::pct);
  //}
  //else {
   // }
   if  (Controller1.ButtonR2.pressing())
{
  slingShot.spinFor(fwd ,90, degrees, false);
 
} 
else if (Controller1.ButtonR1.pressing())
{
  slingShot.spinFor(vex::directionType::rev ,90, degrees, true );
 
} 
if  (Controller1.ButtonX.pressing())
{
 Intake.spin(directionType::fwd);
 
  
} 

else if (Controller1.ButtonB.pressing())
{
  Intake.spin(vex::directionType::rev);
  
  vex_printf("going reverse");
}

 

else 
{
 Intake.stop();
 
  launcher.stop();
  launcher2.stop();
  }//  Controller1.ButtonUp.pressed
//if (Controller1.ButtonA.pressing() )
//{
 // Intake.spin(directionType::rev);
 
  //launcher.spin(directionType::rev);
//} 
//else {
 // Intake.stop();
 
// launcher.stop();
//}
if ((Controller1.ButtonA.pressing())){


  Roller.spin(directionType::fwd);
}
else {
 Roller.stop();
}
   
}
}
void movedat(){

Front_left.spin(vex::directionType::fwd, 50, vex::velocityUnits::pct);
  Front_right.spin(vex::directionType::rev, 50, vex::velocityUnits::pct);
  Back_left.spin(vex::directionType::rev, 50, vex::velocityUnits::pct);
  Back_right.spin(vex::directionType::fwd, 50 , vex::velocityUnits::pct);

 Front_left.spin(vex::directionType::rev,50, vex::velocityUnits::pct);
  Front_right.spin(vex::directionType::fwd, 50, vex::velocityUnits::pct);
  Back_left.spin(vex::directionType::fwd, 50, vex::velocityUnits::pct);
  Back_right.spin(vex::directionType::rev, 50 , vex::velocityUnits::pct);
 

}