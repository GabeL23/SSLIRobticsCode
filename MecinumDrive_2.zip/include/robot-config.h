using namespace vex;

extern brain Brain;
extern motor Front_left;
extern motor Back_left;
extern motor Front_right;
extern motor Back_right;
extern controller Controller1;
extern motor ArmMotorRight;
extern motor ArmMotorLeft;
extern motor ClawMotor;
extern motor Intake ; 
extern motor launcher;
extern motor launcher2; 
extern motor slingShot;
extern motor Roller ; 
/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Text.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void);
