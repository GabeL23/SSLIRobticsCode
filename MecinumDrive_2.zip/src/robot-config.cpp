#include "vex.h"

using namespace vex;

// A global instance of brain used for printing to the V5 brain screen
brain Brain;
vex::motor Front_right (vex::PORT2, vex::gearSetting::ratio18_1,true);
vex::motor Back_right (vex::PORT12, vex::gearSetting::ratio18_1,true);
vex::motor Front_left (vex::PORT1, vex::gearSetting::ratio18_1,false);
vex::motor Back_left (vex::PORT11, vex::gearSetting::ratio18_1,false);
vex::motor Intake (vex::PORT5, vex::gearSetting::ratio18_1, true);

vex::motor launcher (vex::PORT8, vex::gearSetting::ratio18_1,true);
vex::motor Roller (vex:: PORT7,vex::gearSetting::ratio18_1, true );
vex:: motor launcher2  (vex:: PORT9, vex:: gearSetting :: ratio18_1, false );
vex::motor slingShot (vex:: PORT10,vex::gearSetting::ratio18_1, false);
vex::controller Controller1;
/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Text.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void) {
  // Nothing to initialize
}